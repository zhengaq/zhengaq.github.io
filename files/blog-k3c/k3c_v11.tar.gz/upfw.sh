#!/bin/sh
fsmd5="913068d2260a562d548c616e83d90d66"
kernelmd5="7a2204a26ab3693673817f6942e43282"
icount=`ps -w|grep upgrade|grep -v grep|wc -l`
[ "$icount" -gt 0 ] && exit


localfsmd5=`md5sum  /tmp/fs.bin|awk  '{print $1}'`
localkernelmd5=`md5sum  /tmp/kernel.bin|awk  '{print $1}'`
if [ "$fsmd5" == "$localfsmd5" -a "$kernelmd5" == "$localkernelmd5" ] ;then
echo "write firmware,please wait..."
upgrade /tmp/fs.bin rootfs 0 1 
echo "write firmware ok,start write kernel,please wait..."
upgrade /tmp/kernel.bin kernel 1 1
uci set version.num.ver=V1.1 
uci commit version 
sleep 2
echo "upgrade ok!reboot..."
reboot
else
echo "firmware md5 error !"
fi

